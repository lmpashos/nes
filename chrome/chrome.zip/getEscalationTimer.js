chrome.extension.onRequest.addListener(
	function update(request, sender) {
		if (request.greeting == "passingURL") {
			var anchors = document.getElementsByTagName("a");
			var anchor;
			for (var i = 0; i < anchors.length; i++) {
				if (anchors[i] == request.url) {
					anchor = anchors[i];
					break;
				}
			}

			var timer = anchor.parentElement.parentElement.children[10].innerHTML.replace(/(\r\n|\n|\r|\t)/gm,"").trim().split("<br>").pop();

			chrome.extension.sendRequest({greeting: "timerRetrieved1", timer: timer});
		}
	}
);